import os
import shutil
import asyncio
import requests
from python.helpers import memory, perplexica_search, duckduckgo_search, searxng_search
from python.helpers.tool import Tool, Response
from python.helpers.print_style import PrintStyle
from python.helpers.errors import handle_error

class Knowledge(Tool):
    async def execute(self, question="", **kwargs):
        self.clear_pycache()
        # Create tasks for all search methods
        tasks = [
            self.perplexica_search(question),
            self.searxng_search(question),
            self.duckduckgo_search(question),
            self.mem_search(question)
        ]

        # Run all tasks concurrently
        results = await asyncio.gather(*tasks, return_exceptions=True)

        perplexica_result, searxng_result, duckduckgo_result, memory_result = results

        # Handle exceptions and format results
        perplexica_result = self.format_result(perplexica_result, "Perplexica")
        searxng_result = self.format_result(searxng_result, "SearXNG")
        duckduckgo_result = self.format_result(duckduckgo_result, "DuckDuckGo")
        memory_result = self.format_result(memory_result, "Memory")

        msg = self.agent.read_prompt("tool.knowledge.response.md", 
                              online_sources = ((perplexica_result) if perplexica_result else "") + (str(duckduckgo_result) if duckduckgo_result else "") + (str(searxng_search) if searxng_search else ""),
                              memory = memory_result)

        await self.agent.handle_intervention(msg)  # wait for intervention and handle it, if paused

        return Response(message=msg, break_loop=False)

    def clear_pycache(self):
        pycache_dir = os.path.join(os.path.dirname(__file__), '__pycache__')
        if os.path.exists(pycache_dir):
            shutil.rmtree(pycache_dir)
            PrintStyle.hint(f"Deleted {pycache_dir}")
            self.agent.context.log.log(type="hint", content=f"Deleted {pycache_dir}")

    async def perplexica_search(self, question):
        try:
            response = requests.get("http://localhost:3001/api/health")
            if response.status_code == 200:
                result = await asyncio.to_thread(perplexica_search.perplexica_search, question)
                if not result:
                    raise Exception("Perplexica search returned no results")
                return result
        except requests.ConnectionError:
            self.agent.context.log.log(type="hint", content="Perplexica is not running on port 3001. Skipping Perplexica search.")
        except Exception as e:
            self.agent.context.log.log(type="hint", content=f"Perplexica search failed: {str(e)}")
        return None

    async def searxng_search(self, question):
        try:
            response = requests.get("http://localhost:4000/api/health")
            if response.status_code == 200:
                result = await asyncio.to_thread(searxng_search.search, question)
                if not result:
                    raise Exception("SearXNG search returned no results")
                return result
        except requests.ConnectionError:
            self.agent.context.log.log(type="hint", content="SearXNG is not running on port 4000. Skipping SearXNG search.")
        except Exception as e:
            self.agent.context.log.log(type="hint", content=f"SearXNG search failed: {str(e)}")
        return None
        
    async def duckduckgo_search(self, question):
        try:
            return await asyncio.to_thread(duckduckgo_search.search, question)
        except Exception as e:
            self.agent.context.log.log(type="hint", content=f"DuckDuckGo search failed: {str(e)}")
            return None

    async def mem_search(self, question: str):
        db = await memory.Memory.get(self.agent)
        docs = await db.search_similarity_threshold(query=question, limit=5, threshold=0.5)
        text = memory.Memory.format_docs_plain(docs)
        return "\n\n".join(text)

    def format_result(self, result, source):
        if isinstance(result, Exception):
            handle_error(result)
            return f"{source} search failed: {str(result)}"
        return result if result else ""